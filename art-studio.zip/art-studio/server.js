'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const { openDb } = require('./src/db');
const { signToken, verifyToken } = require('./src/auth');
const { buildRoutes } = require('./src/routes');
const { HttpError } = require('./src/util');

const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_SECONDS = 7 * 24 * 3600;
const MAX_BODY_BYTES = 100 * 1024;
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
};

function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY_BYTES) {
        reject(new HttpError(413, 'Request body too large.'));
        req.destroy();
      } else chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error();
        resolve(parsed);
      } catch {
        reject(new HttpError(400, 'Request body must be a JSON object.'));
      }
    });
    req.on('error', reject);
  });
}

function createServer({ db, secret }) {
  const routes = buildRoutes(db);

  function send(res, status, payload, headers = {}) {
    const body = JSON.stringify(payload);
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(body),
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      ...headers,
    });
    res.end(body);
  }

  function serveStatic(req, res, pathname) {
    const rel = pathname === '/' ? '/index.html' : pathname;
    const file = path.normalize(path.join(PUBLIC_DIR, rel));
    if (!file.startsWith(PUBLIC_DIR + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('Not found');
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
    });
    fs.createReadStream(file).pipe(res);
  }

  // Identify the caller. The role always comes from the DATABASE row, never from the
  // token, so changing a user's role takes effect immediately and a token can't claim one.
  function authenticate(req) {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : parseCookies(req.headers.cookie).session;
    const payload = verifyToken(secret, token);
    if (!payload) return null;
    return db.prepare('SELECT * FROM users WHERE id = ?').get(payload.uid) || null;
  }

  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        res.writeHead(405);
        return res.end();
      }
      return serveStatic(req, res, decodeURIComponent(url.pathname));
    }

    try {
      const route = routes.find((r) => r.method === req.method && r.regex.test(url.pathname));
      if (!route) {
        const pathKnown = routes.some((r) => r.regex.test(url.pathname));
        throw new HttpError(pathKnown ? 405 : 404, pathKnown ? 'Method not allowed.' : 'Not found.');
      }

      // 401 / 403 happen BEFORE the body is read or any record is looked up.
      let user = null;
      if (route.roles) {
        user = authenticate(req);
        if (!user) throw new HttpError(401, 'Please log in to continue.');
        if (!route.roles.includes(user.role)) throw new HttpError(403, 'You do not have permission to do that.');
      }

      let body = {};
      if (req.method !== 'GET') {
        // Requiring JSON content-type blocks cross-site <form> posts (CSRF); browsers can't
        // send this header cross-origin without a CORS preflight, which we never approve.
        if (!/^application\/json/i.test(req.headers['content-type'] || '')) {
          throw new HttpError(415, 'Content-Type must be application/json.');
        }
        body = await readJsonBody(req);
      }

      const match = route.regex.exec(url.pathname);
      const params = Object.fromEntries(route.names.map((n, i) => [n, Number(match[i + 1])]));
      const extraHeaders = {};
      const cookie = (value, maxAge) =>
        `session=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}`;
      const ctx = {
        user, params, body,
        login: (u) => { extraHeaders['Set-Cookie'] = cookie(signToken(secret, { uid: u.id }, SESSION_SECONDS), SESSION_SECONDS); },
        logout: () => { extraHeaders['Set-Cookie'] = cookie('', 0); },
      };
      const [status, payload] = route.handler(ctx);
      send(res, status, payload, extraHeaders);
    } catch (err) {
      if (err instanceof HttpError) return send(res, err.status, { error: err.message });
      console.error(err);
      send(res, 500, { error: 'Something went wrong on our side. Please try again.' });
    }
  });
}

module.exports = { createServer };

if (require.main === module) {
  try { process.loadEnvFile(); } catch { /* no .env file; rely on real environment */ }
  let secret = process.env.SESSION_SECRET;
  if (!secret || secret.startsWith('replace-with')) {
    secret = crypto.randomBytes(32).toString('hex');
    console.warn('WARNING: SESSION_SECRET is not set; using a random one. Logins will reset on restart.');
  }
  const db = openDb(process.env.DB_FILE || './data/studio.db');
  const port = Number(process.env.PORT) || 3000;
  createServer({ db, secret }).listen(port, () => console.log(`Art studio running at http://localhost:${port}`));
}
