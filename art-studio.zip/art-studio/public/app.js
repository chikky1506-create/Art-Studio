'use strict';
// Vanilla JS single-page UI. All user-supplied text is inserted with textContent
// (via the h() helper), never innerHTML, so a malicious address/title cannot inject script.

const state = { me: null, meta: null, tab: 'paintings' };
const $ = (sel) => document.querySelector(sel);

// ---- tiny DOM helper --------------------------------------------------------------------
function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (v === true) el.setAttribute(k, '');
    else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const c of children.flat()) if (c != null && c !== false) el.append(c.nodeType ? c : String(c));
  return el;
}
const money = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 });
const badge = (s) => h('span', { class: `badge ${s}` }, s);

// ---- API ----------------------------------------------------------------------------------
async function api(method, path, body) {
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: method === 'GET' ? undefined : JSON.stringify(body || {}),
    });
  } catch {
    throw Object.assign(new Error('Cannot reach the server. Check your connection and try again.'), { status: 0 });
  }
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw Object.assign(new Error(data.error || `Request failed (${res.status}).`), { status: res.status });
  return data;
}

let toastTimer;
function toast(message, isError) {
  const t = $('#toast');
  t.textContent = message;
  t.className = isError ? 'error' : '';
  t.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.style.display = 'none'; }, 5000);
}

// Run an action, show its result or its refusal message, then refresh the screen.
async function act(fn, okMessage, refresh) {
  try {
    await fn();
    if (okMessage) toast(okMessage);
  } catch (err) {
    if (err.status === 401) return showLogin();
    toast(err.message, true);
  }
  if (refresh) refresh();
}

// ---- the loading / empty / error pattern used by EVERY list ---------------------------------
// load(): returns an array.  render(items): returns a node.
function dataView({ load, render, empty }) {
  const box = h('div');
  const run = async () => {
    box.replaceChildren(h('div', { class: 'state' }, 'Loading…'));
    try {
      const items = await load();
      box.replaceChildren(items.length ? render(items) : h('div', { class: 'state' }, empty));
    } catch (err) {
      if (err.status === 401) return showLogin();
      box.replaceChildren(h('div', { class: 'state error', role: 'alert' }, err.message, ' ',
        h('button', { class: 'btn secondary', onclick: run }, 'Try again')));
    }
  };
  run();
  box.reload = run;
  return box;
}

// ---- auth ---------------------------------------------------------------------------------
function showLogin() {
  state.me = null;
  renderChrome();
  let signup = false;
  const draw = () => {
    const email = h('input', { type: 'email', name: 'email', required: true, autocomplete: 'email' });
    const pw = h('input', { type: 'password', name: 'password', required: true, minlength: signup ? 8 : 1, autocomplete: signup ? 'new-password' : 'current-password' });
    const name = h('input', { type: 'text', name: 'name', required: true, maxlength: 100 });
    const submit = h('button', { class: 'btn', type: 'submit' }, signup ? 'Create account' : 'Log in');
    const form = h('form', { class: 'card', onsubmit: async (e) => {
      e.preventDefault();
      submit.disabled = true;
      try {
        const body = signup ? { name: name.value, email: email.value, password: pw.value } : { email: email.value, password: pw.value };
        await api('POST', signup ? '/api/auth/signup' : '/api/auth/login', body);
        await boot();
      } catch (err) { toast(err.message, true); submit.disabled = false; }
    } },
      h('h2', null, signup ? 'Create a customer account' : 'Log in'),
      signup && h('label', null, 'Name', name),
      h('label', null, 'Email', email),
      h('label', null, signup ? 'Password (min 8 characters)' : 'Password', pw),
      submit,
      h('button', { class: 'btn secondary', type: 'button', onclick: () => { signup = !signup; draw(); } },
        signup ? 'I already have an account' : 'New customer? Sign up'));
    $('#main').replaceChildren(form);
  };
  draw();
}

// ---- chrome (nav + who) -----------------------------------------------------------------------
const TABS = [['paintings', 'Paintings'], ['orders', 'Orders'], ['bookings', 'Wall painting'], ['pottery', 'Pottery']];
function renderChrome() {
  const nav = $('#nav'), who = $('#who');
  if (!state.me) { nav.replaceChildren(); who.replaceChildren(); return; }
  nav.replaceChildren(...TABS.map(([id, label]) =>
    h('button', { 'aria-current': state.tab === id ? 'page' : null, onclick: () => { state.tab = id; show(); } }, label)));
  who.replaceChildren(`${state.me.name} (${state.me.role === 'admin' ? 'studio' : 'customer'}) `,
    h('button', { class: 'btn secondary', onclick: async () => { await api('POST', '/api/auth/logout'); state.meta = null; showLogin(); } }, 'Log out'));
}

function show() {
  renderChrome();
  const screens = { paintings: paintingsScreen, orders: ordersScreen, bookings: bookingsScreen, pottery: potteryScreen };
  $('#main').replaceChildren(screens[state.tab]());
}

const isAdmin = () => state.me.role === 'admin';
const who = (r) => (isAdmin() ? h('div', { class: 'muted' }, `Customer: ${r.customer_name} <${r.customer_email}>`) : null);

// ---- paintings --------------------------------------------------------------------------------
function paintingsScreen() {
  const wrap = h('div', null, h('h2', null, 'Paintings'));
  const list = dataView({
    empty: isAdmin() ? 'No paintings yet. Add the first one above.' : 'No paintings are available right now. Please check back soon.',
    load: async () => (await api('GET', '/api/paintings')).paintings,
    render: (items) => h('div', { class: 'grid' }, items.map((p) => paintingCard(p, () => list.reload(), form))),
  });
  let form = null;
  if (isAdmin()) { form = paintingForm(() => list.reload()); wrap.append(form.el); }
  wrap.append(list);
  return wrap;
}

function paintingCard(p, refresh, form) {
  const actions = h('div', { class: 'actions' });
  if (!isAdmin() && p.status === 'available') {
    const btn = h('button', { class: 'btn', onclick: () => {
      btn.disabled = true;
      act(() => api('POST', '/api/orders', { paintingId: p.id }), `Order placed for “${p.title}”.`, refresh);
    } }, `Buy for ${money(p.price)}`);
    actions.append(btn);
  }
  if (isAdmin() && p.status === 'available') actions.append(h('button', { class: 'btn secondary', onclick: () => form.edit(p) }, 'Edit'));
  return h('div', { class: 'card' },
    h('div', { class: 'row' }, h('strong', null, p.title), badge(p.status)),
    p.artist && h('div', { class: 'muted' }, `by ${p.artist}`),
    p.description && h('p', null, p.description),
    h('div', null, money(p.price)),
    p.status === 'sold' && !isAdmin() && h('div', { class: 'muted' }, 'This painting has been sold.'),
    actions);
}

function paintingForm(refresh) {
  let editingId = null;
  const f = {
    title: h('input', { required: true, maxlength: 150 }),
    artist: h('input', { maxlength: 100 }),
    description: h('textarea', { rows: 2, maxlength: 1000 }),
    price: h('input', { type: 'number', min: 1, step: '0.01', required: true }),
  };
  const heading = h('h3', null, 'Add a painting');
  const submit = h('button', { class: 'btn', type: 'submit' }, 'Add painting');
  const cancel = h('button', { class: 'btn secondary', type: 'button', hidden: true, onclick: () => reset() }, 'Cancel edit');
  const reset = () => {
    editingId = null; heading.textContent = 'Add a painting'; submit.textContent = 'Add painting'; cancel.hidden = true;
    for (const k in f) f[k].value = '';
  };
  const el = h('form', { class: 'card', onsubmit: (e) => {
    e.preventDefault();
    const body = { title: f.title.value, artist: f.artist.value, description: f.description.value, price: Number(f.price.value) };
    const id = editingId;
    act(async () => { await (id ? api('PATCH', `/api/paintings/${id}`, body) : api('POST', '/api/paintings', body)); reset(); },
      id ? 'Painting updated.' : 'Painting added.', refresh);
  } },
    heading,
    h('label', null, 'Title', f.title), h('label', null, 'Artist (optional)', f.artist),
    h('label', null, 'Description (optional)', f.description), h('label', null, 'Price (₹)', f.price),
    h('div', { class: 'actions' }, submit, cancel));
  return {
    el,
    edit(p) {
      editingId = p.id; heading.textContent = `Edit “${p.title}”`; submit.textContent = 'Save changes'; cancel.hidden = false;
      f.title.value = p.title; f.artist.value = p.artist; f.description.value = p.description; f.price.value = p.price;
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    },
  };
}

// ---- orders -----------------------------------------------------------------------------------
function ordersScreen() {
  const list = dataView({
    empty: isAdmin() ? 'No orders have been placed yet.' : 'You have not bought any paintings yet. Browse the Paintings tab.',
    load: async () => (await api('GET', '/api/orders')).orders,
    render: (items) => h('div', null, items.map((o) => h('div', { class: 'card' },
      h('div', { class: 'row' }, h('strong', null, o.painting_title), badge(o.status)),
      h('div', null, `${money(o.price)} · ordered ${o.created_at}`), who(o),
      !isAdmin() && o.status === 'placed' && h('div', { class: 'actions' },
        h('button', { class: 'btn danger', onclick: () => {
          if (confirm(`Cancel your order for “${o.painting_title}”? The painting will become available to others.`)) {
            act(() => api('POST', `/api/orders/${o.id}/cancel`), 'Order cancelled.', () => list.reload());
          }
        } }, 'Cancel order'))))),
  });
  return h('div', null, h('h2', null, isAdmin() ? 'All orders' : 'My orders'), list);
}

// ---- wall bookings ------------------------------------------------------------------------------
const addDays = (iso, n) => { const [y, m, d] = iso.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10); };

function bookingsScreen() {
  const wrap = h('div', null, h('h2', null, isAdmin() ? 'All wall painting bookings' : 'Book a wall painting'));
  const list = dataView({
    empty: isAdmin() ? 'No bookings yet.' : 'You have no bookings yet.',
    load: async () => (await api('GET', '/api/bookings')).bookings,
    render: (items) => h('div', null, items.map((b) => {
      const actions = h('div', { class: 'actions' });
      if (isAdmin() && b.status === 'requested') {
        actions.append(
          h('button', { class: 'btn', onclick: () => act(() => api('POST', `/api/bookings/${b.id}/confirm`), 'Booking confirmed.', () => list.reload()) }, 'Confirm'),
          h('button', { class: 'btn danger', onclick: () => act(() => api('POST', `/api/bookings/${b.id}/decline`), 'Booking declined.', () => list.reload()) }, 'Decline'));
      }
      if (!isAdmin() && ['requested', 'confirmed'].includes(b.status)) {
        actions.append(h('button', { class: 'btn danger', onclick: () => {
          if (confirm(`Cancel the booking for ${b.date}? Cancellation is only possible until 3 days before.`)) {
            act(() => api('POST', `/api/bookings/${b.id}/cancel`), 'Booking cancelled.', () => { list.reload(); loadTaken(); });
          }
        } }, 'Cancel booking'));
      }
      return h('div', { class: 'card' },
        h('div', { class: 'row' }, h('strong', null, b.date), badge(b.status)),
        h('div', null, `${b.sqft} sq ft × ${money(b.rate)} = ${money(b.price)}`),
        h('div', { class: 'muted' }, b.address), who(b), actions);
    })),
  });

  let loadTaken = () => {};
  if (!isAdmin()) {
    const m = state.meta;
    const date = h('input', { type: 'date', required: true, min: addDays(m.today, 7), max: addDays(m.today, 90) });
    const sqft = h('input', { type: 'number', required: true, min: 10, max: 500, step: 'any' });
    const address = h('textarea', { required: true, rows: 2, minlength: 5, maxlength: 300 });
    const price = h('div', { class: 'hint' }, `Rate: ${money(m.wallRatePerSqFt)} per sq ft. Enter the wall size to see the price.`);
    const taken = h('div', { class: 'muted' }, 'Loading booked dates…');
    sqft.addEventListener('input', () => {
      const v = Number(sqft.value);
      price.textContent = v >= 10 && v <= 500 ? `Price: ${v} sq ft × ${money(m.wallRatePerSqFt)} = ${money(Math.round(v * m.wallRatePerSqFt * 100) / 100)}` : `Wall size must be 10 to 500 sq ft. Rate: ${money(m.wallRatePerSqFt)} per sq ft.`;
    });
    loadTaken = async () => {
      try {
        const { dates } = await api('GET', '/api/bookings/taken-dates');
        taken.textContent = dates.length ? `Already booked: ${dates.join(', ')}` : 'No dates are booked yet.';
      } catch (err) { taken.textContent = `Could not load booked dates: ${err.message}`; }
    };
    loadTaken();
    const submit = h('button', { class: 'btn', type: 'submit' }, 'Request booking');
    wrap.append(h('form', { class: 'card', onsubmit: (e) => {
      e.preventDefault();
      submit.disabled = true;
      act(() => api('POST', '/api/bookings', { date: date.value, sqft: Number(sqft.value), address: address.value }),
        'Booking requested. The studio will confirm or decline it.', () => { submit.disabled = false; list.reload(); loadTaken(); });
    } },
      h('div', { class: 'muted' }, 'Pick a date 7 to 90 days from today. Each date can be booked once.'),
      h('label', null, 'Date', date), h('label', null, 'Wall size (sq ft, 10–500)', sqft),
      h('label', null, 'Address', address), price, taken, submit));
    wrap.append(h('h3', null, 'My bookings'));
  }
  wrap.append(list);
  return wrap;
}

// ---- pottery --------------------------------------------------------------------------------------
function potteryScreen() {
  const wrap = h('div', null, h('h2', null, isAdmin() ? 'All pottery requests' : 'Request custom pottery'));
  let form = null;
  const list = dataView({
    empty: isAdmin() ? 'No pottery requests yet.' : 'You have no pottery requests yet.',
    load: async () => (await api('GET', '/api/pottery')).requests,
    render: (items) => h('div', null, items.map((r) => {
      const actions = h('div', { class: 'actions' });
      if (isAdmin() && r.status === 'requested') {
        actions.append(
          h('button', { class: 'btn', onclick: () => act(() => api('POST', `/api/pottery/${r.id}/accept`), 'Request accepted.', () => list.reload()) }, 'Accept'),
          h('button', { class: 'btn danger', onclick: () => act(() => api('POST', `/api/pottery/${r.id}/decline`), 'Request declined.', () => list.reload()) }, 'Decline'));
      }
      if (!isAdmin() && r.status === 'requested') {
        actions.append(
          h('button', { class: 'btn secondary', onclick: () => form.edit(r) }, 'Edit'),
          h('button', { class: 'btn danger', onclick: () => { if (confirm('Cancel this pottery request?')) act(() => api('POST', `/api/pottery/${r.id}/cancel`), 'Request cancelled.', () => list.reload()); } }, 'Cancel'));
      }
      return h('div', { class: 'card' },
        h('div', { class: 'row' }, h('strong', null, `${r.quantity} × ${r.item} (${r.glaze})`), badge(r.status)),
        h('div', { class: 'muted' }, `Needed by ${r.needed_by}`), who(r), actions);
    })),
  });

  if (!isAdmin()) {
    const m = state.meta;
    let editingId = null;
    const item = h('select', { required: true }, m.potteryItems.map((n) => h('option', { value: n }, n)));
    const glaze = h('select', { required: true }, m.glazes.map((n) => h('option', { value: n }, n)));
    const quantity = h('input', { type: 'number', required: true, min: 1, max: 12, step: 1, value: 1 });
    const neededBy = h('input', { type: 'date', required: true, min: addDays(m.today, 14) });
    const heading = h('h3', null, 'New request');
    const submit = h('button', { class: 'btn', type: 'submit' }, 'Send request');
    const cancel = h('button', { class: 'btn secondary', type: 'button', hidden: true, onclick: () => reset() }, 'Cancel edit');
    const reset = () => { editingId = null; heading.textContent = 'New request'; submit.textContent = 'Send request'; cancel.hidden = true; quantity.value = 1; neededBy.value = ''; };
    const el = h('form', { class: 'card', onsubmit: (e) => {
      e.preventDefault();
      const body = { item: item.value, glaze: glaze.value, quantity: Number(quantity.value), neededBy: neededBy.value };
      const id = editingId;
      act(async () => { await (id ? api('PATCH', `/api/pottery/${id}`, body) : api('POST', '/api/pottery', body)); reset(); },
        id ? 'Request updated.' : 'Request sent. The studio will accept or decline it.', () => list.reload());
    } },
      heading, h('label', null, 'Item', item), h('label', null, 'Glaze', glaze),
      h('label', null, 'Quantity (1–12)', quantity), h('label', null, 'Needed by (at least 14 days away)', neededBy),
      h('div', { class: 'actions' }, submit, cancel));
    form = { edit(r) {
      editingId = r.id; heading.textContent = 'Edit request'; submit.textContent = 'Save changes'; cancel.hidden = false;
      item.value = r.item; glaze.value = r.glaze; quantity.value = r.quantity; neededBy.value = r.needed_by;
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } };
    wrap.append(el, h('h3', null, 'My requests'));
  }
  wrap.append(list);
  return wrap;
}

// ---- start-up -------------------------------------------------------------------------------------
async function boot() {
  $('#main').replaceChildren(h('div', { class: 'state' }, 'Loading…'));
  try {
    state.me = (await api('GET', '/api/me')).user;
    state.meta = (await api('GET', '/api/meta'));
    state.tab = 'paintings';
    show();
  } catch (err) {
    if (err.status === 401) return showLogin();
    $('#main').replaceChildren(h('div', { class: 'state error', role: 'alert' }, err.message, ' ',
      h('button', { class: 'btn secondary', onclick: boot }, 'Try again')));
  }
}
boot();
