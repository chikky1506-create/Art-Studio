'use strict';
const { tx, isUniqueViolation } = require('./db');
const { hashPassword, verifyPassword } = require('./auth');
const { HttpError, bad, todayStr, isValidDate, daysFromToday, str, num, round2 } = require('./util');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Route table entry: [method, pattern, roles, handler]
//   roles = null        -> public (no login needed)
//   roles = ['customer'] / ['admin'] / ['customer','admin'] -> login + role check
// Order of checks on every protected request: 401 (not logged in) -> 403 (wrong role)
// -> 404 (record missing OR owned by someone else) -> 409 (state conflict) -> 200.
function buildRoutes(db) {
  const routes = [];
  const route = (method, pattern, roles, handler) => routes.push({ method, pattern, roles, handler });

  const one = (sql, ...args) => db.prepare(sql).get(...args);
  const all = (sql, ...args) => db.prepare(sql).all(...args);
  const setting = (key) => (one('SELECT value FROM settings WHERE key = ?', key) || {}).value;

  // Fetch a record by id. A customer asking for someone else's record gets 404, same as
  // a record that does not exist, so ids cannot be probed. Admins can see everything.
  function getRecord(table, id, user, label) {
    const row = one(`SELECT * FROM ${table} WHERE id = ?`, id);
    if (!row || (user.role === 'customer' && row.user_id !== user.id)) {
      throw new HttpError(404, `${label} not found.`);
    }
    return row;
  }
  const publicUser = (u) => ({ id: u.id, email: u.email, name: u.name, role: u.role });

  // ================= auth (public) =====================================================
  route('POST', '/api/auth/signup', null, ({ body, login }) => {
    const email = str(body.email, 'Email', { max: 200 }).toLowerCase();
    if (!EMAIL_RE.test(email)) throw bad('Please enter a valid email address.');
    const name = str(body.name, 'Name', { max: 100 });
    const password = str(body.password, 'Password', { min: 8, max: 200 });
    if (one('SELECT id FROM users WHERE email = ?', email)) {
      throw new HttpError(409, 'An account with this email already exists.');
    }
    // Sign-up ALWAYS creates a customer. The studio account is created by the seed script.
    const info = db
      .prepare("INSERT INTO users (email, name, password_hash, role) VALUES (?, ?, ?, 'customer')")
      .run(email, name, hashPassword(password));
    const user = one('SELECT * FROM users WHERE id = ?', Number(info.lastInsertRowid));
    login(user);
    return [201, { user: publicUser(user) }];
  });

  route('POST', '/api/auth/login', null, ({ body, login }) => {
    const email = String(body.email || '').trim().toLowerCase();
    const user = one('SELECT * FROM users WHERE email = ?', email);
    const ok = user && verifyPassword(String(body.password || ''), user.password_hash);
    if (!ok) throw new HttpError(401, 'Incorrect email or password.');
    login(user);
    return [200, { user: publicUser(user) }];
  });

  route('POST', '/api/auth/logout', null, ({ logout }) => {
    logout();
    return [200, { ok: true }];
  });

  route('GET', '/api/me', ['customer', 'admin'], ({ user }) => [200, { user: publicUser(user) }]);

  // Reference data the forms need: rate, pottery items, glazes, today's date, limits.
  route('GET', '/api/meta', ['customer', 'admin'], () => [
    200,
    {
      today: todayStr(),
      wallRatePerSqFt: Number(setting('wall_rate_per_sqft')),
      potteryItems: all('SELECT name FROM pottery_items ORDER BY name').map((r) => r.name),
      glazes: all('SELECT name FROM glazes ORDER BY name').map((r) => r.name),
    },
  ]);

  // ================= paintings =========================================================
  const paintingSelect = `
    SELECT p.*, CASE WHEN EXISTS (SELECT 1 FROM orders o WHERE o.painting_id = p.id AND o.status = 'placed')
                     THEN 'sold' ELSE 'available' END AS status
    FROM paintings p`;

  route('GET', '/api/paintings', ['customer', 'admin'], () => [
    200,
    { paintings: all(`${paintingSelect} ORDER BY p.id DESC`) },
  ]);

  function paintingFields(body, existing = {}) {
    return {
      title: str(body.title ?? existing.title, 'Title', { max: 150 }),
      artist: str(body.artist ?? existing.artist, 'Artist', { max: 100, optional: true }),
      description: str(body.description ?? existing.description, 'Description', { max: 1000, optional: true }),
      price: round2(num(body.price ?? existing.price, 'Price', { min: 1, max: 100000000 })),
    };
  }

  route('POST', '/api/paintings', ['admin'], ({ body }) => {
    const f = paintingFields(body);
    const info = db
      .prepare('INSERT INTO paintings (title, artist, description, price) VALUES (?, ?, ?, ?)')
      .run(f.title, f.artist, f.description, f.price);
    return [201, { painting: one(`${paintingSelect} WHERE p.id = ?`, Number(info.lastInsertRowid)) }];
  });

  route('PATCH', '/api/paintings/:id', ['admin'], ({ params, body }) =>
    tx(db, () => {
      const current = one(`${paintingSelect} WHERE p.id = ?`, params.id);
      if (!current) throw new HttpError(404, 'Painting not found.');
      if (current.status !== 'available') {
        throw new HttpError(409, 'This painting has been sold and can no longer be edited.');
      }
      const f = paintingFields(body, current);
      db.prepare('UPDATE paintings SET title = ?, artist = ?, description = ?, price = ? WHERE id = ?')
        .run(f.title, f.artist, f.description, f.price, current.id);
      return [200, { painting: one(`${paintingSelect} WHERE p.id = ?`, current.id) }];
    }));

  // ================= orders ============================================================
  const orderSelect = `
    SELECT o.*, p.title AS painting_title, u.name AS customer_name, u.email AS customer_email
    FROM orders o JOIN paintings p ON p.id = o.painting_id JOIN users u ON u.id = o.user_id`;

  route('POST', '/api/orders', ['customer'], ({ user, body }) => {
    const paintingId = num(body.paintingId, 'paintingId', { min: 1, max: Number.MAX_SAFE_INTEGER, integer: true });
    return tx(db, () => {
      const painting = one('SELECT * FROM paintings WHERE id = ?', paintingId);
      if (!painting) throw new HttpError(404, 'Painting not found.');
      const sold = one("SELECT 1 AS x FROM orders WHERE painting_id = ? AND status = 'placed'", paintingId);
      const soldMsg = 'Sorry, this painting was just sold to someone else.';
      if (sold) throw new HttpError(409, soldMsg);
      let info;
      try {
        info = db
          .prepare("INSERT INTO orders (user_id, painting_id, price, status) VALUES (?, ?, ?, 'placed')")
          .run(user.id, paintingId, painting.price);
      } catch (err) {
        // Backstop: the partial unique index rejects a second placed order for the painting.
        if (isUniqueViolation(err)) throw new HttpError(409, soldMsg);
        throw err;
      }
      return [201, { order: one(`${orderSelect} WHERE o.id = ?`, Number(info.lastInsertRowid)) }];
    });
  });

  route('GET', '/api/orders', ['customer', 'admin'], ({ user }) => {
    const rows =
      user.role === 'admin'
        ? all(`${orderSelect} ORDER BY o.id DESC`)
        : all(`${orderSelect} WHERE o.user_id = ? ORDER BY o.id DESC`, user.id);
    return [200, { orders: rows }];
  });

  route('GET', '/api/orders/:id', ['customer', 'admin'], ({ user, params }) => {
    getRecord('orders', params.id, user, 'Order');
    return [200, { order: one(`${orderSelect} WHERE o.id = ?`, params.id) }];
  });

  route('POST', '/api/orders/:id/cancel', ['customer'], ({ user, params }) =>
    tx(db, () => {
      const order = getRecord('orders', params.id, user, 'Order');
      if (order.status !== 'placed') throw new HttpError(409, 'This order is already cancelled.');
      db.prepare("UPDATE orders SET status = 'cancelled', cancelled_at = datetime('now') WHERE id = ?").run(order.id);
      // The painting becomes available again automatically: its status is derived from
      // "is there a placed order", and this order no longer is one.
      return [200, { order: one(`${orderSelect} WHERE o.id = ?`, order.id) }];
    }));

  // ================= wall bookings =====================================================
  const bookingSelect = `
    SELECT b.*, u.name AS customer_name, u.email AS customer_email
    FROM bookings b JOIN users u ON u.id = b.user_id`;

  // Dates already held by a live booking (no personal data) so the form can show them.
  route('GET', '/api/bookings/taken-dates', ['customer', 'admin'], () => [
    200,
    { dates: all("SELECT date FROM bookings WHERE status IN ('requested','confirmed') AND date >= ? ORDER BY date", todayStr()).map((r) => r.date) },
  ]);

  route('POST', '/api/bookings', ['customer'], ({ user, body }) => {
    if (!isValidDate(body.date)) throw bad('Please choose a valid date (YYYY-MM-DD).');
    const away = daysFromToday(body.date);
    if (away < 7 || away > 90) throw bad('The date must be between 7 and 90 days from today.');
    const sqft = num(body.sqft, 'Wall size', { min: 10, max: 500 });
    const address = str(body.address, 'Address', { min: 5, max: 300 });
    return tx(db, () => {
      const rate = Number(setting('wall_rate_per_sqft'));
      if (!Number.isFinite(rate)) throw new HttpError(500, 'Wall rate is not configured. Run the seed script.');
      const taken = 'Sorry, that date was just booked by someone else. Please pick another date.';
      if (one("SELECT 1 AS x FROM bookings WHERE date = ? AND status IN ('requested','confirmed')", body.date)) {
        throw new HttpError(409, taken);
      }
      let info;
      try {
        info = db
          .prepare("INSERT INTO bookings (user_id, date, sqft, address, rate, price, status) VALUES (?, ?, ?, ?, ?, ?, 'requested')")
          .run(user.id, body.date, sqft, address, rate, round2(sqft * rate));
      } catch (err) {
        if (isUniqueViolation(err)) throw new HttpError(409, taken); // backstop: unique index
        throw err;
      }
      return [201, { booking: one(`${bookingSelect} WHERE b.id = ?`, Number(info.lastInsertRowid)) }];
    });
  });

  route('GET', '/api/bookings', ['customer', 'admin'], ({ user }) => {
    const rows =
      user.role === 'admin'
        ? all(`${bookingSelect} ORDER BY b.date DESC, b.id DESC`)
        : all(`${bookingSelect} WHERE b.user_id = ? ORDER BY b.date DESC, b.id DESC`, user.id);
    return [200, { bookings: rows }];
  });

  route('GET', '/api/bookings/:id', ['customer', 'admin'], ({ user, params }) => {
    getRecord('bookings', params.id, user, 'Booking');
    return [200, { booking: one(`${bookingSelect} WHERE b.id = ?`, params.id) }];
  });

  route('POST', '/api/bookings/:id/cancel', ['customer'], ({ user, params }) =>
    tx(db, () => {
      const b = getRecord('bookings', params.id, user, 'Booking');
      if (!['requested', 'confirmed'].includes(b.status)) {
        throw new HttpError(409, `This booking is already ${b.status} and cannot be cancelled.`);
      }
      if (daysFromToday(b.date) < 3) {
        throw new HttpError(409, 'Bookings can only be cancelled until 3 days before the date.');
      }
      db.prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?").run(b.id);
      return [200, { booking: one(`${bookingSelect} WHERE b.id = ?`, b.id) }];
    }));

  for (const [action, newStatus] of [['confirm', 'confirmed'], ['decline', 'declined']]) {
    route('POST', `/api/bookings/:id/${action}`, ['admin'], ({ params }) =>
      tx(db, () => {
        const b = one('SELECT * FROM bookings WHERE id = ?', params.id);
        if (!b) throw new HttpError(404, 'Booking not found.');
        if (b.status !== 'requested') {
          throw new HttpError(409, `Only a requested booking can be ${newStatus}. This one is ${b.status}.`);
        }
        db.prepare('UPDATE bookings SET status = ? WHERE id = ?').run(newStatus, b.id);
        return [200, { booking: one(`${bookingSelect} WHERE b.id = ?`, b.id) }];
      }));
  }

  // ================= pottery requests ==================================================
  const potterySelect = `
    SELECT r.*, u.name AS customer_name, u.email AS customer_email
    FROM pottery_requests r JOIN users u ON u.id = r.user_id`;

  function potteryFields(body, existing = {}) {
    const item = str(body.item ?? existing.item, 'Item', { max: 100 });
    const glaze = str(body.glaze ?? existing.glaze, 'Glaze', { max: 100 });
    if (!one('SELECT 1 AS x FROM pottery_items WHERE name = ?', item)) throw bad('Please choose an item from the list.');
    if (!one('SELECT 1 AS x FROM glazes WHERE name = ?', glaze)) throw bad('Please choose a glaze from the list.');
    const quantity = num(body.quantity ?? existing.quantity, 'Quantity', { min: 1, max: 12, integer: true });
    const neededBy = body.neededBy ?? existing.needed_by;
    if (!isValidDate(neededBy)) throw bad('Please choose a valid needed-by date (YYYY-MM-DD).');
    if (daysFromToday(neededBy) < 14) throw bad('The needed-by date must be at least 14 days from today.');
    return { item, glaze, quantity, neededBy };
  }

  route('POST', '/api/pottery', ['customer'], ({ user, body }) => {
    const f = potteryFields(body);
    const info = db
      .prepare("INSERT INTO pottery_requests (user_id, item, glaze, quantity, needed_by, status) VALUES (?, ?, ?, ?, ?, 'requested')")
      .run(user.id, f.item, f.glaze, f.quantity, f.neededBy);
    return [201, { request: one(`${potterySelect} WHERE r.id = ?`, Number(info.lastInsertRowid)) }];
  });

  route('GET', '/api/pottery', ['customer', 'admin'], ({ user }) => {
    const rows =
      user.role === 'admin'
        ? all(`${potterySelect} ORDER BY r.id DESC`)
        : all(`${potterySelect} WHERE r.user_id = ? ORDER BY r.id DESC`, user.id);
    return [200, { requests: rows }];
  });

  route('GET', '/api/pottery/:id', ['customer', 'admin'], ({ user, params }) => {
    getRecord('pottery_requests', params.id, user, 'Pottery request');
    return [200, { request: one(`${potterySelect} WHERE r.id = ?`, params.id) }];
  });

  route('PATCH', '/api/pottery/:id', ['customer'], ({ user, params, body }) =>
    tx(db, () => {
      const r = getRecord('pottery_requests', params.id, user, 'Pottery request');
      if (r.status !== 'requested') {
        throw new HttpError(409, `This request is already ${r.status} and can no longer be edited.`);
      }
      const f = potteryFields(body, r);
      db.prepare("UPDATE pottery_requests SET item = ?, glaze = ?, quantity = ?, needed_by = ?, updated_at = datetime('now') WHERE id = ?")
        .run(f.item, f.glaze, f.quantity, f.neededBy, r.id);
      return [200, { request: one(`${potterySelect} WHERE r.id = ?`, r.id) }];
    }));

  route('POST', '/api/pottery/:id/cancel', ['customer'], ({ user, params }) =>
    tx(db, () => {
      const r = getRecord('pottery_requests', params.id, user, 'Pottery request');
      if (r.status !== 'requested') {
        throw new HttpError(409, `This request is already ${r.status} and can no longer be cancelled.`);
      }
      db.prepare("UPDATE pottery_requests SET status = 'cancelled', updated_at = datetime('now') WHERE id = ?").run(r.id);
      return [200, { request: one(`${potterySelect} WHERE r.id = ?`, r.id) }];
    }));

  for (const [action, newStatus] of [['accept', 'accepted'], ['decline', 'declined']]) {
    route('POST', `/api/pottery/:id/${action}`, ['admin'], ({ params }) =>
      tx(db, () => {
        const r = one('SELECT * FROM pottery_requests WHERE id = ?', params.id);
        if (!r) throw new HttpError(404, 'Pottery request not found.');
        if (r.status !== 'requested') {
          throw new HttpError(409, `Only a requested item can be ${newStatus}. This one is ${r.status}.`);
        }
        db.prepare("UPDATE pottery_requests SET status = ?, updated_at = datetime('now') WHERE id = ?").run(newStatus, r.id);
        return [200, { request: one(`${potterySelect} WHERE r.id = ?`, r.id) }];
      }));
  }

  // Compile "/api/orders/:id/cancel" style patterns into regexes once.
  for (const r of routes) {
    const names = [];
    const src = r.pattern.replace(/:([a-z]+)/g, (_, n) => (names.push(n), '(\\d+)'));
    r.regex = new RegExp(`^${src}$`);
    r.names = names;
  }
  return routes;
}

module.exports = { buildRoutes };
