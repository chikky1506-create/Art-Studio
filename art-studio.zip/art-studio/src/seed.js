'use strict';
// Usage: npm run seed            (reads .env, then SEED_FILE or ./seed/seedData.json)
//        node src/seed.js path/to/seedData.json
const fs = require('node:fs');
const path = require('node:path');
const { openDb, tx } = require('./db');
const { hashPassword } = require('./auth');

function loadSeed(db, seed, { adminEmail, adminPassword }) {
  if (!Number.isFinite(seed.wallRatePerSqFt) || seed.wallRatePerSqFt <= 0) {
    throw new Error('seed: "wallRatePerSqFt" must be a positive number');
  }
  for (const key of ['potteryItems', 'glazes']) {
    if (!Array.isArray(seed[key]) || !seed[key].length) throw new Error(`seed: "${key}" must be a non-empty array`);
  }
  tx(db, () => {
    db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
      .run('wall_rate_per_sqft', String(seed.wallRatePerSqFt));
    for (const name of seed.potteryItems) db.prepare('INSERT OR IGNORE INTO pottery_items (name) VALUES (?)').run(String(name));
    for (const name of seed.glazes) db.prepare('INSERT OR IGNORE INTO glazes (name) VALUES (?)').run(String(name));

    // Idempotent: a painting already present (same title + artist) is skipped.
    for (const p of seed.paintings || []) {
      const exists = db.prepare('SELECT 1 AS x FROM paintings WHERE title = ? AND artist = ?').get(p.title, p.artist || '');
      if (!exists) {
        db.prepare('INSERT INTO paintings (title, artist, description, price) VALUES (?, ?, ?, ?)')
          .run(p.title, p.artist || '', p.description || '', p.price);
      }
    }

    // The single studio/admin account (studio sign-up is out of scope).
    if (!db.prepare('SELECT 1 AS x FROM users WHERE email = ?').get(adminEmail.toLowerCase())) {
      db.prepare("INSERT INTO users (email, name, password_hash, role) VALUES (?, 'Studio', ?, 'admin')")
        .run(adminEmail.toLowerCase(), hashPassword(adminPassword));
    }
  });
}

module.exports = { loadSeed };

if (require.main === module) {
  try { process.loadEnvFile(); } catch { /* no .env */ }
  const adminEmail = process.env.ADMIN_EMAIL;
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (!adminEmail || !adminPassword || adminPassword.startsWith('replace-with')) {
    console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD in .env (see .env.example) before seeding.');
    process.exit(1);
  }
  const file = path.resolve(process.argv[2] || process.env.SEED_FILE || './seed/seedData.json');
  const seed = JSON.parse(fs.readFileSync(file, 'utf8'));
  const db = openDb(process.env.DB_FILE || './data/studio.db');
  loadSeed(db, seed, { adminEmail, adminPassword });
  console.log(`Seeded from ${file}. Studio login: ${adminEmail}`);
}
