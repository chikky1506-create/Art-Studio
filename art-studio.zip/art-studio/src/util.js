'use strict';

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const bad = (msg) => new HttpError(400, msg);

// ---- dates: day-granularity, studio time zone (IST) ------------------------------------
const TZ = 'Asia/Kolkata';
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function todayStr() {
  return new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(new Date()); // YYYY-MM-DD
}
function isValidDate(s) {
  if (typeof s !== 'string' || !DATE_RE.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}
const dayNumber = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return Date.UTC(y, m - 1, d) / 86400000;
};
const daysFromToday = (s) => dayNumber(s) - dayNumber(todayStr());

// ---- input validation ------------------------------------------------------------------
function str(v, name, { min = 1, max = 200, optional = false } = {}) {
  if (v === undefined || v === null || v === '') {
    if (optional) return '';
    throw bad(`${name} is required.`);
  }
  if (typeof v !== 'string') throw bad(`${name} must be text.`);
  const t = v.trim();
  if (t.length < min) throw bad(`${name} must be at least ${min} characters.`);
  if (t.length > max) throw bad(`${name} must be at most ${max} characters.`);
  return t;
}
function num(v, name, { min, max, integer = false }) {
  if (typeof v !== 'number' || !Number.isFinite(v)) throw bad(`${name} must be a number.`);
  if (integer && !Number.isInteger(v)) throw bad(`${name} must be a whole number.`);
  if (v < min || v > max) throw bad(`${name} must be between ${min} and ${max}.`);
  return v;
}
const round2 = (n) => Math.round(n * 100) / 100;

module.exports = { HttpError, bad, todayStr, isValidDate, daysFromToday, str, num, round2 };
