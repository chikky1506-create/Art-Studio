'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('customer','admin')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pottery_items (name TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS glazes (name TEXT PRIMARY KEY);

CREATE TABLE IF NOT EXISTS paintings (
  id          INTEGER PRIMARY KEY,
  title       TEXT NOT NULL,
  artist      TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  price       REAL NOT NULL CHECK (price > 0),
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id           INTEGER PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id),
  painting_id  INTEGER NOT NULL REFERENCES paintings(id),
  price        REAL NOT NULL,
  status       TEXT NOT NULL CHECK (status IN ('placed','cancelled')),
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  cancelled_at TEXT
);
-- A painting may have at most ONE placed order at any time (cancelled ones don't count).
CREATE UNIQUE INDEX IF NOT EXISTS one_placed_order_per_painting
  ON orders(painting_id) WHERE status = 'placed';

CREATE TABLE IF NOT EXISTS bookings (
  id         INTEGER PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  date       TEXT NOT NULL,            -- YYYY-MM-DD
  sqft       REAL NOT NULL,
  address    TEXT NOT NULL,
  rate       REAL NOT NULL,            -- rate per sq ft at time of booking
  price      REAL NOT NULL,            -- sqft * rate, frozen at booking time
  status     TEXT NOT NULL CHECK (status IN ('requested','confirmed','declined','cancelled')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- A date can be held by at most ONE live booking. Declined/cancelled bookings free the date.
CREATE UNIQUE INDEX IF NOT EXISTS one_live_booking_per_date
  ON bookings(date) WHERE status IN ('requested','confirmed');

CREATE TABLE IF NOT EXISTS pottery_requests (
  id         INTEGER PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  item       TEXT NOT NULL,
  glaze      TEXT NOT NULL,
  quantity   INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 12),
  needed_by  TEXT NOT NULL,            -- YYYY-MM-DD
  status     TEXT NOT NULL CHECK (status IN ('requested','accepted','declined','cancelled')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`;

function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  return db;
}

// Run fn inside a write transaction. BEGIN IMMEDIATE takes the write lock up front so
// "check then insert" cannot interleave with another writer, even across processes.
function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch { /* already rolled back */ }
    throw err;
  }
}

const isUniqueViolation = (err) => /UNIQUE constraint failed/i.test(String(err && err.message));

module.exports = { openDb, tx, isUniqueViolation };
