# DESIGN.md

## How do login and the two roles work?

Customers sign up with name, email and password. Sign-up can only ever create a **customer**; the single **studio/admin** account is created by `npm run seed` from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env`.

Passwords are hashed with scrypt and a random salt. On login the server sets an `HttpOnly`, `SameSite=Lax` cookie holding a signed token (`{ user id, expiry }` + HMAC-SHA256 using `SESSION_SECRET`). The token carries **no role**: on every request the server verifies the signature, loads the user row, and uses the role stored in the database.

Every route in `src/routes.js` declares which roles may call it, and `server.js` enforces it before reading the body or touching any record: no valid session → **401**, wrong role → **403**. For records a customer owns, a lookup helper returns **404** if the record doesn't exist *or* belongs to someone else, so ids can't be probed. Admins can read all records. Mutating requests must be `application/json`, which blocks cross-site form posts (CSRF).

## Which database did you choose, and why?

**SQLite**, using Node's built-in `node:sqlite` module. I chose it because it needs no setup or accounts, so anyone can run the project on a clean machine with just Node, and it supports real transactions and partial unique indexes, which are exactly what the "only once" rules need. It is a local file, not a cloud-hosted database (the brief said cloud was preferred but not evaluated). Moving to a hosted Postgres would mean changing `src/db.js` and the SQL dialect details in `routes.js`, and the same constraints exist there.

## How do you stop two people from taking the same painting or date?

Two layers, with the database as the real guarantee:

1. **Database constraints.** A partial unique index allows only one `placed` order per painting (`orders(painting_id) WHERE status='placed'`), and only one live booking per date (`bookings(date) WHERE status IN ('requested','confirmed')`). Cancelled orders and declined/cancelled bookings fall outside the index, which is what frees the painting or date again. If two requests race, the second insert is rejected by the database no matter what the application code did.
2. **Transaction + friendly check.** Each buy/book runs inside `BEGIN IMMEDIATE` (takes the write lock first), checks "already sold/taken?", then inserts. A unique-index violation is caught and turned into the same clear **409** message ("just sold", "just booked"). The UI shows that message and refreshes the list.

Tests cover both: 12 simultaneous buyers of one painting and 12 simultaneous bookers of one date each produce exactly one success, and a separate test inserts directly into the database to show the indexes alone refuse duplicates. A painting's "sold" status is *derived* from whether a placed order exists, so cancelling an order can never leave the painting stuck as sold.

## What did you finish, what did you leave out, and what would you do next?

**Finished**
- Sign-up, login, logout; customer and studio roles enforced server-side (401/403/404 as specified).
- Paintings: admin adds, and edits only while available; customers browse, buy and cancel; cancelled painting becomes available again.
- Wall bookings: date 7–90 days away (IST), wall size 10–500 sq ft, address, one booking per date, price = size × rate, studio confirm/decline, customer cancel until 3 days before.
- Pottery: item and glaze from the seed data, quantity 1–12, needed-by at least 14 days away, studio accept/decline, customer edit/cancel only while *requested*.
- Customers see only their own orders/bookings/requests; the studio sees all.
- Every data screen has loading, empty and error (with retry) states; refusals show clear messages.
- 12 automated API tests, plus a browser run of the full flow (sign-up, buy, cancel, book, pottery, studio confirm/accept).

**Left out / known limits**
- **The official `seedData.zip` was not available when I built this**, so `seed/seedData.json` holds placeholder values (wall rate, pottery items, glazes, sample paintings). They must be replaced with the real data (see README); I assumed a single flat per-sq-ft wall rate.
- Painting prices/rates are plain numbers in ₹ with no currency handling; no image uploads, payments, emails or mobile layout (all out of scope per the brief).
- Not deployed; the database is a local SQLite file; no rate limiting on login attempts.
- Declined bookings can't be re-opened, and the studio can't cancel or delete anything (per the RBAC table).
- "Today" and the 7/90/14/3-day rules use India time (Asia/Kolkata).

**Next**
- Load the official seed data and confirm the rate rules match.
- Add login rate limiting, and move to a hosted database if multiple server instances are needed.
- Add pagination for long lists, and a studio view filtered by status.
