'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');

const { openDb } = require('../src/db');
const { loadSeed } = require('../src/seed');
const { createServer } = require('../server');
const { todayStr } = require('../src/util');

let server, base, db;
const ADMIN = { email: 'studio@test.dev', password: 'admin-password-1' };

function inDays(n) {
  const [y, m, d] = todayStr().split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

// Tiny client: keeps the session cookie for one user.
function client() {
  let cookie = '';
  const call = async (method, path, body, { json = true } = {}) => {
    const headers = {};
    if (json) headers['Content-Type'] = 'application/json';
    if (cookie) headers.Cookie = cookie;
    const res = await fetch(base + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    let data = null;
    try { data = await res.json(); } catch { /* no body */ }
    return { status: res.status, data };
  };
  return {
    get: (p) => call('GET', p),
    post: (p, b = {}) => call('POST', p, b),
    patch: (p, b = {}) => call('PATCH', p, b),
    raw: call,
  };
}

let seq = 0;
async function newCustomer() {
  const c = client();
  const r = await c.post('/api/auth/signup', { name: 'Cust', email: `c${++seq}@test.dev`, password: 'password-123' });
  assert.equal(r.status, 201);
  return c;
}
async function adminClient() {
  const c = client();
  const r = await c.post('/api/auth/login', ADMIN);
  assert.equal(r.status, 200);
  return c;
}

before(async () => {
  db = openDb(':memory:');
  loadSeed(db, {
    wallRatePerSqFt: 100,
    potteryItems: ['Mug', 'Bowl'],
    glazes: ['Celadon', 'Matte White'],
    paintings: [],
  }, { adminEmail: ADMIN.email, adminPassword: ADMIN.password });
  server = createServer({ db, secret: 'test-secret' });
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

test('401: every protected endpoint refuses anonymous callers', async () => {
  const anon = client();
  const endpoints = [
    ['GET', '/api/me'], ['GET', '/api/meta'], ['GET', '/api/paintings'], ['POST', '/api/paintings'],
    ['PATCH', '/api/paintings/1'], ['POST', '/api/orders'], ['GET', '/api/orders'], ['GET', '/api/orders/1'],
    ['POST', '/api/orders/1/cancel'], ['POST', '/api/bookings'], ['GET', '/api/bookings'],
    ['GET', '/api/bookings/taken-dates'], ['GET', '/api/bookings/1'], ['POST', '/api/bookings/1/cancel'],
    ['POST', '/api/bookings/1/confirm'], ['POST', '/api/bookings/1/decline'], ['POST', '/api/pottery'],
    ['GET', '/api/pottery'], ['GET', '/api/pottery/1'], ['PATCH', '/api/pottery/1'],
    ['POST', '/api/pottery/1/cancel'], ['POST', '/api/pottery/1/accept'], ['POST', '/api/pottery/1/decline'],
  ];
  for (const [m, p] of endpoints) {
    const r = await anon.raw(m, p, m === 'GET' ? undefined : {});
    assert.equal(r.status, 401, `${m} ${p} should be 401, got ${r.status}`);
  }
});

test('sign-up always creates a customer, even if a role is sent', async () => {
  const c = client();
  const r = await c.post('/api/auth/signup', { name: 'Sneaky', email: 'sneaky@test.dev', password: 'password-123', role: 'admin' });
  assert.equal(r.status, 201);
  assert.equal(r.data.user.role, 'customer');
  assert.equal((await c.post('/api/paintings', { title: 'x', price: 10 })).status, 403);
});

test('login rejects wrong passwords; tampered cookies are not accepted', async () => {
  const c = client();
  assert.equal((await c.post('/api/auth/login', { email: ADMIN.email, password: 'nope' })).status, 401);
  const res = await fetch(base + '/api/me', { headers: { Cookie: 'session=abc.def' } });
  assert.equal(res.status, 401);
});

test('403: wrong role is refused on every restricted action', async () => {
  const cust = await newCustomer();
  const admin = await adminClient();
  // customer attempting admin actions
  assert.equal((await cust.post('/api/paintings', { title: 'T', price: 10 })).status, 403);
  assert.equal((await cust.patch('/api/paintings/1', { title: 'T' })).status, 403);
  assert.equal((await cust.post('/api/bookings/1/confirm')).status, 403);
  assert.equal((await cust.post('/api/bookings/1/decline')).status, 403);
  assert.equal((await cust.post('/api/pottery/1/accept')).status, 403);
  assert.equal((await cust.post('/api/pottery/1/decline')).status, 403);
  // admin attempting customer actions
  assert.equal((await admin.post('/api/orders', { paintingId: 1 })).status, 403);
  assert.equal((await admin.post('/api/bookings', { date: inDays(10), sqft: 50, address: '1 Main Street' })).status, 403);
  assert.equal((await admin.post('/api/pottery', { item: 'Mug', glaze: 'Celadon', quantity: 1, neededBy: inDays(20) })).status, 403);
  assert.equal((await admin.post('/api/orders/1/cancel')).status, 403);
  assert.equal((await admin.post('/api/bookings/1/cancel')).status, 403);
  assert.equal((await admin.post('/api/pottery/1/cancel')).status, 403);
  assert.equal((await admin.patch('/api/pottery/1', { quantity: 2 })).status, 403);
});

test('mutating requests must be JSON (CSRF guard)', async () => {
  const cust = await newCustomer();
  const r = await cust.raw('POST', '/api/orders', undefined, { json: false });
  assert.equal(r.status, 415);
});

test('paintings: admin adds/edits while available; buy, cancel, and re-buy flow', async () => {
  const admin = await adminClient();
  const a = await newCustomer();
  const b = await newCustomer();

  const created = await admin.post('/api/paintings', { title: 'Sunrise', artist: 'Me', description: 'd', price: 5000 });
  assert.equal(created.status, 201);
  const id = created.data.painting.id;
  assert.equal(created.data.painting.status, 'available');
  assert.equal((await admin.post('/api/paintings', { title: '', price: 5 })).status, 400);
  assert.equal((await admin.post('/api/paintings', { title: 'Bad', price: -5 })).status, 400);

  assert.equal((await admin.patch(`/api/paintings/${id}`, { price: 5500 })).data.painting.price, 5500);

  const order = await a.post('/api/orders', { paintingId: id });
  assert.equal(order.status, 201);
  assert.equal(order.data.order.price, 5500);

  // sold: second buyer refused with a clear message, admin cannot edit
  const second = await b.post('/api/orders', { paintingId: id });
  assert.equal(second.status, 409);
  assert.match(second.data.error, /sold/i);
  assert.equal((await admin.patch(`/api/paintings/${id}`, { price: 1 })).status, 409);
  const listed = (await a.get('/api/paintings')).data.paintings.find((p) => p.id === id);
  assert.equal(listed.status, 'sold');

  // cancel -> available again -> someone else can buy
  assert.equal((await a.post(`/api/orders/${order.data.order.id}/cancel`)).data.order.status, 'cancelled');
  assert.equal((await a.post(`/api/orders/${order.data.order.id}/cancel`)).status, 409);
  assert.equal((await a.get('/api/paintings')).data.paintings.find((p) => p.id === id).status, 'available');
  assert.equal((await b.post('/api/orders', { paintingId: id })).status, 201);
  assert.equal((await a.post('/api/orders', { paintingId: 999999 })).status, 404);
});

test('RACE: 12 customers buy the same painting at once -> exactly one wins', async () => {
  const admin = await adminClient();
  const id = (await admin.post('/api/paintings', { title: 'Race', price: 100 })).data.painting.id;
  const customers = await Promise.all(Array.from({ length: 12 }, newCustomer));
  const results = await Promise.all(customers.map((c) => c.post('/api/orders', { paintingId: id })));
  assert.equal(results.filter((r) => r.status === 201).length, 1);
  assert.equal(results.filter((r) => r.status === 409).length, 11);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM orders WHERE painting_id = ? AND status='placed'").get(id).n, 1);
});

test('RACE: 12 customers book the same date at once -> exactly one wins', async () => {
  const date = inDays(40);
  const customers = await Promise.all(Array.from({ length: 12 }, newCustomer));
  const results = await Promise.all(
    customers.map((c) => c.post('/api/bookings', { date, sqft: 100, address: '12 Race Road' })),
  );
  assert.equal(results.filter((r) => r.status === 201).length, 1);
  assert.equal(results.filter((r) => r.status === 409).length, 11);
});

test('bookings: validation, pricing, confirm/decline, date reuse and cancel rules', async () => {
  const admin = await adminClient();
  const a = await newCustomer();
  const ok = { sqft: 100, address: '221B Baker Street' };

  assert.equal((await a.post('/api/bookings', { ...ok, date: inDays(6) })).status, 400);
  assert.equal((await a.post('/api/bookings', { ...ok, date: inDays(91) })).status, 400);
  assert.equal((await a.post('/api/bookings', { ...ok, date: 'not-a-date' })).status, 400);
  assert.equal((await a.post('/api/bookings', { ...ok, date: '2026-02-30' })).status, 400);
  assert.equal((await a.post('/api/bookings', { ...ok, date: inDays(50), sqft: 9 })).status, 400);
  assert.equal((await a.post('/api/bookings', { ...ok, date: inDays(50), sqft: 501 })).status, 400);
  assert.equal((await a.post('/api/bookings', { ...ok, date: inDays(50), sqft: '100' })).status, 400);
  assert.equal((await a.post('/api/bookings', { ...ok, date: inDays(50), address: '' })).status, 400);

  // boundaries are inclusive
  const first = await a.post('/api/bookings', { ...ok, date: inDays(7), sqft: 10 });
  assert.equal(first.status, 201);
  assert.equal(first.data.booking.price, 1000); // 10 sq ft * rate 100
  assert.equal(first.data.booking.status, 'requested');
  assert.equal((await a.post('/api/bookings', { ...ok, date: inDays(90), sqft: 500 })).data.booking.price, 50000);

  // taken date is visible and refused for others
  const b = await newCustomer();
  assert.ok((await b.get('/api/bookings/taken-dates')).data.dates.includes(inDays(7)));
  const dup = await b.post('/api/bookings', { ...ok, date: inDays(7) });
  assert.equal(dup.status, 409);
  assert.match(dup.data.error, /booked/i);

  // admin confirms; cannot re-decide
  const id = first.data.booking.id;
  assert.equal((await admin.post(`/api/bookings/${id}/confirm`)).data.booking.status, 'confirmed');
  assert.equal((await admin.post(`/api/bookings/${id}/decline`)).status, 409);
  assert.equal((await admin.post('/api/bookings/999999/confirm')).status, 404);

  // a declined booking frees its date
  const c = await newCustomer();
  const held = await c.post('/api/bookings', { ...ok, date: inDays(60) });
  assert.equal((await admin.post(`/api/bookings/${held.data.booking.id}/decline`)).data.booking.status, 'declined');
  assert.equal((await b.post('/api/bookings', { ...ok, date: inDays(60) })).status, 201);

  // cancelling frees the date too
  const mine = await c.post('/api/bookings', { ...ok, date: inDays(70) });
  assert.equal((await c.post(`/api/bookings/${mine.data.booking.id}/cancel`)).data.booking.status, 'cancelled');
  assert.equal((await b.post('/api/bookings', { ...ok, date: inDays(70) })).status, 201);

  // cannot cancel inside the 3-day window (move the date forward directly in the DB)
  const late = await c.post('/api/bookings', { ...ok, date: inDays(80) });
  db.prepare('UPDATE bookings SET date = ? WHERE id = ?').run(inDays(2), late.data.booking.id);
  const tooLate = await c.post(`/api/bookings/${late.data.booking.id}/cancel`);
  assert.equal(tooLate.status, 409);
  assert.match(tooLate.data.error, /3 days/);
  // exactly 3 days before is still allowed
  db.prepare('UPDATE bookings SET date = ? WHERE id = ?').run(inDays(3), late.data.booking.id);
  assert.equal((await c.post(`/api/bookings/${late.data.booking.id}/cancel`)).status, 200);
});

test('pottery: validation, edit/cancel only while requested, admin decisions', async () => {
  const admin = await adminClient();
  const a = await newCustomer();
  const ok = { item: 'Mug', glaze: 'Celadon', quantity: 4, neededBy: inDays(14) };

  assert.equal((await a.post('/api/pottery', { ...ok, neededBy: inDays(13) })).status, 400);
  assert.equal((await a.post('/api/pottery', { ...ok, quantity: 0 })).status, 400);
  assert.equal((await a.post('/api/pottery', { ...ok, quantity: 13 })).status, 400);
  assert.equal((await a.post('/api/pottery', { ...ok, quantity: 2.5 })).status, 400);
  assert.equal((await a.post('/api/pottery', { ...ok, item: 'Teapot' })).status, 400);
  assert.equal((await a.post('/api/pottery', { ...ok, glaze: 'Neon' })).status, 400);

  const created = await a.post('/api/pottery', ok);
  assert.equal(created.status, 201);
  const id = created.data.request.id;
  assert.equal(created.data.request.status, 'requested');

  const edited = await a.patch(`/api/pottery/${id}`, { quantity: 6, glaze: 'Matte White' });
  assert.equal(edited.data.request.quantity, 6);
  assert.equal(edited.data.request.glaze, 'Matte White');
  assert.equal((await a.patch(`/api/pottery/${id}`, { quantity: 99 })).status, 400);

  assert.equal((await admin.post(`/api/pottery/${id}/accept`)).data.request.status, 'accepted');
  assert.equal((await a.patch(`/api/pottery/${id}`, { quantity: 2 })).status, 409);
  assert.equal((await a.post(`/api/pottery/${id}/cancel`)).status, 409);
  assert.equal((await admin.post(`/api/pottery/${id}/decline`)).status, 409);

  const second = await a.post('/api/pottery', ok);
  assert.equal((await admin.post(`/api/pottery/${second.data.request.id}/decline`)).data.request.status, 'declined');
  const third = await a.post('/api/pottery', ok);
  assert.equal((await a.post(`/api/pottery/${third.data.request.id}/cancel`)).data.request.status, 'cancelled');
});

test('404: customers cannot see or touch other customers\' records; admin sees all', async () => {
  const admin = await adminClient();
  const owner = await newCustomer();
  const other = await newCustomer();

  const pid = (await admin.post('/api/paintings', { title: 'Mine', price: 10 })).data.painting.id;
  const order = (await owner.post('/api/orders', { paintingId: pid })).data.order;
  const booking = (await owner.post('/api/bookings', { date: inDays(33), sqft: 20, address: '9 Owner Lane' })).data.booking;
  const pottery = (await owner.post('/api/pottery', { item: 'Bowl', glaze: 'Celadon', quantity: 1, neededBy: inDays(30) })).data.request;

  for (const p of [`/api/orders/${order.id}`, `/api/bookings/${booking.id}`, `/api/pottery/${pottery.id}`]) {
    assert.equal((await other.get(p)).status, 404, `GET ${p}`);
    assert.equal((await owner.get(p)).status, 200, `owner GET ${p}`);
    assert.equal((await admin.get(p)).status, 200, `admin GET ${p}`);
  }
  assert.equal((await other.post(`/api/orders/${order.id}/cancel`)).status, 404);
  assert.equal((await other.post(`/api/bookings/${booking.id}/cancel`)).status, 404);
  assert.equal((await other.post(`/api/pottery/${pottery.id}/cancel`)).status, 404);
  assert.equal((await other.patch(`/api/pottery/${pottery.id}`, { quantity: 3 })).status, 404);

  // list endpoints are scoped to the owner
  assert.equal((await other.get('/api/orders')).data.orders.length, 0);
  assert.equal((await other.get('/api/bookings')).data.bookings.length, 0);
  assert.equal((await other.get('/api/pottery')).data.requests.length, 0);
  assert.ok((await owner.get('/api/orders')).data.orders.some((o) => o.id === order.id));
  assert.ok((await admin.get('/api/orders')).data.orders.some((o) => o.id === order.id));
  assert.ok((await admin.get('/api/bookings')).data.bookings.some((b) => b.id === booking.id));
  assert.ok((await admin.get('/api/pottery')).data.requests.some((r) => r.id === pottery.id));

  // the other customer's failed attempts changed nothing
  assert.equal((await owner.get(`/api/orders/${order.id}`)).data.order.status, 'placed');
});

test('DB constraints alone block double-selling and double-booking (backstop if app checks are bypassed)', () => {
  const uid = db.prepare("SELECT id FROM users WHERE role='admin'").get().id;
  const pid = Number(db.prepare("INSERT INTO paintings (title, price) VALUES ('Idx', 1)").run().lastInsertRowid);
  const addOrder = () => db.prepare("INSERT INTO orders (user_id, painting_id, price, status) VALUES (?, ?, 1, 'placed')").run(uid, pid);
  addOrder();
  assert.throws(addOrder, /UNIQUE constraint failed/);

  const date = inDays(85);
  const addBooking = (status) => db.prepare("INSERT INTO bookings (user_id, date, sqft, address, rate, price, status) VALUES (?, ?, 10, 'addr', 1, 10, ?)").run(uid, date, status);
  addBooking('requested');
  assert.throws(() => addBooking('confirmed'), /UNIQUE constraint failed/);
  addBooking('declined'); // non-live rows may share the date
  addBooking('cancelled');
});
